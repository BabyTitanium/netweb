create view room_valve_info as
  select
    `hsp`.`name`      AS `branch_name`,
    `hes`.`id`        AS `area_id`,
    `hes`.`name`      AS `area_name`,
    `z`.`id`          AS `zone_id`,
    `z`.`z_name`      AS `z_name`,
    `b`.`id`          AS `build_id`,
    `b`.`build_num`   AS `b_num`,
    `b`.`build_name`  AS `b_name`,
    `u`.`id`          AS `unit_id`,
    `u`.`unit_name`   AS `u_name`,
    `u`.`unit_num`    AS `u_num`,
    `ra`.`valve_addr` AS `valve_addr`,
    `r`.`id`          AS `id`,
    `r`.`room_num`    AS `r_num`,
    `r`.`is_supply`   AS `is_supply`,
    `info`.`coll_num` AS `vcollector_id`,
    `info`.`net_num`  AS `v_net_id`,
    `info`.`prot_num` AS `valve_protocol`
  from (((((((`scale_db`.`branch_company` `hsp`
    join `scale_db`.`heat_area` `hes`) join `scale_db`.`zones` `z`) join `scale_db`.`builds` `b`) join
    `scale_db`.`units` `u`) join `scale_db`.`rooms` `r`) join `scale_db`.`room_valve_addr` `ra`) join
    `scale_db`.`valve_info` `info`)
  where (
    (`hsp`.`id` = `hes`.`branch_company_id`) and (`hes`.`id` = `z`.`heat_e_station_id`) and (`z`.`id` = `b`.`zone_id`)
    and (`b`.`id` = `u`.`build_id`) and (`u`.`id` = `r`.`unit_id`) and (`r`.`id` = `ra`.`room_id`) and
    (`ra`.`valve_addr` = `info`.`valve_addr`) and (`hsp`.`available` = 0) and (`hes`.`available` = 0) and
    (`z`.`available` = 0) and (`ra`.`stopped` = 0));

