create view gis_view_tep as
  select
    `hsp`.`name`     AS `hsp_name`,
    `hsp`.`id`       AS `hsp_id`,
    `hes`.`name`     AS `hes_name`,
    `hes`.`id`       AS `hes_id`,
    `z`.`id`         AS `z_id`,
    `z`.`z_name`     AS `z_name`,
    `b`.`id`         AS `b_id`,
    `b`.`build_num`  AS `b_num`,
    `b`.`build_name` AS `b_name`
  from (((`scale_db`.`branch_company` `hsp`
    join `scale_db`.`heat_area` `hes`) join `scale_db`.`zones` `z`) join `scale_db`.`builds` `b`)
  where (
    (`hsp`.`id` = `hes`.`branch_company_id`) and (`hes`.`id` = `z`.`heat_e_station_id`) and (`z`.`id` = `b`.`zone_id`)
    and (`hsp`.`available` = 0) and (`hes`.`available` = 0) and (`z`.`available` = 0));

