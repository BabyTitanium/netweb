create view room_meter_info as
  select
    `hsp`.`name`      AS `branch_name`,
    `hes`.`id`        AS `area_id`,
    `hes`.`name`      AS `area_name`,
    `z`.`id`          AS `zone_id`,
    `z`.`z_name`      AS `z_name`,
    `b`.`id`          AS `build_id`,
    `b`.`build_num`   AS `b_num`,
    `b`.`build_name`  AS `b_name`,
    `u`.`id`          AS `unit_id`,
    `u`.`unit_name`   AS `u_name`,
    `u`.`unit_num`    AS `u_num`,
    `ra`.`meter_addr` AS `meter_addr`,
    `r`.`id`          AS `id`,
    `r`.`room_num`    AS `r_num`,
    `r`.`is_supply`   AS `is_supply`
  from ((((((`test`.`branch_company` `hsp`
    join `test`.`heat_area` `hes`) join `test`.`zones` `z`) join `test`.`builds` `b`) join `test`.`units` `u`) join
    `test`.`rooms` `r`) join `test`.`room_meter_addr` `ra`)
  where (
    (`hsp`.`id` = `hes`.`branch_company_id`) and (`hes`.`id` = `z`.`heat_e_station_id`) and (`z`.`id` = `b`.`zone_id`)
    and (`b`.`id` = `u`.`build_id`) and (`u`.`id` = `r`.`unit_id`) and (`r`.`id` = `ra`.`room_id`) and
    (`hsp`.`available` = 0) and (`hes`.`available` = 0) and (`z`.`available` = 0) and (`ra`.`stopped` = 0));

