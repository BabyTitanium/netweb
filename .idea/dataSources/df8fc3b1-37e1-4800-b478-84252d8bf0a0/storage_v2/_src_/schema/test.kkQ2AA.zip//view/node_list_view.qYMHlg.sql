create view node_list_view as
  select
    `hsp`.`name`       AS `branch_name`,
    `hes`.`id`         AS `area_id`,
    `hes`.`name`       AS `area_name`,
    `z`.`id`           AS `zone_id`,
    `z`.`z_name`       AS `z_name`,
    `b`.`id`           AS `build_id`,
    `b`.`build_num`    AS `b_num`,
    `b`.`build_name`   AS `b_name`,
    `u`.`id`           AS `unit_id`,
    `u`.`unit_name`    AS `u_name`,
    `u`.`unit_num`     AS `u_num`,
    `r`.`id`           AS `id`,
    `r`.`room_num`     AS `r_num`,
    `r`.`room_name`    AS `room_name`,
    `r`.`location`     AS `location`,
    `r`.`user_code`    AS `user_code`,
    `r`.`host_name`    AS `host_name`,
    `r`.`contact_info` AS `contact_info`,
    `r`.`floor`        AS `floor`,
    `r`.`room_area`    AS `room_area`,
    `r`.`heat_area`    AS `heat_area`,
    `r`.`is_supply`    AS `is_supply`,
    `r`.`user_type`    AS `user_type`,
    `r`.`contract_num` AS `contract_num`,
    `r`.`heat_type`    AS `heat_type`,
    `r`.`notes`        AS `notes`,
    `r`.`update_time`  AS `update_time`,
    `r`.`special_mark` AS `special_mark`,
    `r`.`charge_mode`  AS `charge_mode`
  from (((((`test`.`branch_company` `hsp`
    join `test`.`heat_area` `hes`) join `test`.`zones` `z`) join `test`.`builds` `b`) join `test`.`units` `u`) join
    `test`.`rooms` `r`)
  where (
    (`hsp`.`id` = `hes`.`branch_company_id`) and (`hes`.`id` = `z`.`heat_e_station_id`) and (`z`.`id` = `b`.`zone_id`)
    and (`b`.`id` = `u`.`build_id`) and (`u`.`id` = `r`.`unit_id`) and (`hsp`.`available` = 0) and
    (`hes`.`available` = 0) and (`z`.`available` = 0));

